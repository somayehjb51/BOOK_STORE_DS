class Node:
    def __init__(self, name):
        self.name = name

class DynamicArray:
    def __init__(self):
        self.data = []
        self.count = 0
    
    def append(self, item):
        self.data.append(item)
        self.count += 1
    
    def remove(self, item):
        for i in range(self.count):
            if self.data[i] == item:
                for j in range(i, self.count - 1):
                    self.data[j] = self.data[j + 1]
                self.count -= 1
                return True
        return False
    
    def find_by_name(self, name):
        for i in range(self.count):
            if self.data[i].name == name:
                return self.data[i]
        return None
    
    def __len__(self):
        return self.count
    
    def __getitem__(self, index):
        if 0 <= index < self.count:
            return self.data[index]
        return None
    
    def clear(self):
        self.data = []
        self.count = 0

class Book(Node):
    def __init__(self, name, author, price):
        super().__init__(name)
        self.author = author
        self.price = price
    
    def __str__(self):
        return f"{self.name} by {self.author} - ${self.price}"

class Category(Node):
    def __init__(self, name):
        super().__init__(name)
        self.subcategories = DynamicArray()
        self.books = DynamicArray()
    
    def add_subcategory(self, category):
        self.subcategories.append(category)
    
    def add_book(self, book):
        self.books.append(book)
    
    def remove_subcategory(self, category):
        return self.subcategories.remove(category)
    
    def remove_book(self, book):
        return self.books.remove(book)
    
    def find_book_by_name(self, book_name):
        return self.books.find_by_name(book_name)
    
    def find_category_by_name(self, category_name):
        return self.subcategories.find_by_name(category_name)
    
    def get_all_books_recursive(self, result=None):
        if result is None:
            result = []
        
        for i in range(len(self.books)):
            result.append(self.books[i])
        
        for i in range(len(self.subcategories)):
            self.subcategories[i].get_all_books_recursive(result)
        
        return result
    
    def find_book_in_tree(self, book_name):
        book = self.find_book_by_name(book_name)
        if book:
            return book
        
        for i in range(len(self.subcategories)):
            result = self.subcategories[i].find_book_in_tree(book_name)
            if result:
                return result
        
        return None
    
    def find_category_in_tree(self, category_name):
        if self.name == category_name:
            return self
        
        for i in range(len(self.subcategories)):
            result = self.subcategories[i].find_category_in_tree(category_name)
            if result:
                return result
        
        return None

class BookSystem:
    def __init__(self):
        self.root = Category("Root")
        self.all_books = []
    
    def add_category(self, category_name, parent_category_name):
        if self.find_category(category_name):
            return False, f"Category '{category_name}' already exists."
        
        parent = self.find_category(parent_category_name)
        if not parent:
            return False, f"Parent category '{parent_category_name}' not found."
        
        new_category = Category(category_name)
        parent.add_subcategory(new_category)
        return True, f"Category '{category_name}' added."
    
    def remove_category(self, category_name):
        if category_name == "Root":
            return False, "Cannot delete Root category."
        
        category = self.find_category(category_name)
        if not category:
            return False, f"Category '{category_name}' not found."
        
        parent = self._find_parent(category_name, self.root)
        if parent:
            parent.remove_subcategory(category)
        
        all_books_in_category = category.get_all_books_recursive()
        for book in all_books_in_category:
            self._remove_book_from_all_books(book.name)
        
        return True, f"Category '{category_name}' deleted."
    
    def _find_parent(self, category_name, current, parent=None):
        if current.name == category_name:
            return parent
        
        for i in range(len(current.subcategories)):
            result = self._find_parent(category_name, current.subcategories[i], current)
            if result:
                return result
        
        return None
    
    def add_book(self, book_name, author, price, category_name):
        if self.find_book(book_name):
            return False, f"Book '{book_name}' already exists."
        
        try:
            price = float(price)
            if price <= 0:
                return False, "Price must be positive."
        except:
            return False, "Invalid price."
        
        category = self.find_category(category_name)
        if not category:
            return False, f"Category '{category_name}' not found."
        
        new_book = Book(book_name, author, price)
        category.add_book(new_book)
        self.all_books.append(new_book)
        
        return True, f"Book '{book_name}' added."
    
    def remove_book(self, book_name):
        book_info = self.find_book(book_name)
        if not book_info:
            return False, f"Book '{book_name}' not found."
        
        category = self._find_book_category(book_name, self.root)
        if category:
            category.remove_book(book_info)
        
        self._remove_book_from_all_books(book_name)
        
        return True, f"Book '{book_name}' deleted."
    
    def _find_book_category(self, book_name, current_category):
        if current_category.find_book_by_name(book_name):
            return current_category
        
        for i in range(len(current_category.subcategories)):
            result = self._find_book_category(book_name, current_category.subcategories[i])
            if result:
                return result
        
        return None
    
    def _remove_book_from_all_books(self, book_name):
        for i in range(len(self.all_books)):
            if self.all_books[i].name == book_name:
                del self.all_books[i]
                break
    
    def show_books_in_category(self, category_name):
        category = self.find_category(category_name)
        if not category:
            return False, f"Category '{category_name}' not found."
        
        all_books = category.get_all_books_recursive()
        
        if len(all_books) == 0:
            return True, f"No books in '{category_name}'."
        
        result = f"Books in '{category_name}':\n"
        for i, book in enumerate(all_books):
            result += f"{i+1}. {book}\n"
        
        return True, result
    
    def search_book(self, book_name):
        book = self.find_book(book_name)
        if not book:
            return False, f"Book '{book_name}' not found."
        
        return True, str(book)
    
    def find_category(self, category_name):
        return self.root.find_category_in_tree(category_name)
    
    def find_book(self, book_name):
        return self.root.find_book_in_tree(book_name)
    
    def display_category_tree(self, category=None, level=0):
        if category is None:
            category = self.root
        
        indent = "  " * level
        result = f"{indent}+ {category.name}"
        
        if len(category.books) > 0:
            result += f" ({len(category.books)} books)"
        
        result += "\n"
        
        for i in range(len(category.subcategories)):
            result += self.display_category_tree(category.subcategories[i], level + 1)
        
        return result

def main():
    system = BookSystem()
    
    print("=" * 50)
    print("BOOK STORE SYSTEM")
    print("=" * 50)
    
    while True:
        print("\nMENU:")
        print("1. Add category")
        print("2. Delete category")
        print("3. Add book")
        print("4. Delete book")
        print("5. Show category books")
        print("6. Search book")
        print("7. Show tree")
        print("8. Exit")
        
        choice = input("Choice: ")
        
        if choice == "1":
            name = input("Category name: ")
            parent = input("Parent category: ")
            ok, msg = system.add_category(name, parent)
            print("OK" if ok else "ERROR", msg)
        
        elif choice == "2":
            name = input("Category to delete: ")
            ok, msg = system.remove_category(name)
            print("OK" if ok else "ERROR", msg)
        
        elif choice == "3":
            name = input("Book name: ")
            author = input("Author: ")
            price = input("Price: ")
            cat = input("Category: ")
            ok, msg = system.add_book(name, author, price, cat)
            print("OK" if ok else "ERROR", msg)
        
        elif choice == "4":
            name = input("Book to delete: ")
            ok, msg = system.remove_book(name)
            print("OK" if ok else "ERROR", msg)
        
        elif choice == "5":
            name = input("Category: ")
            ok, msg = system.show_books_in_category(name)
            print(msg)
        
        elif choice == "6":
            name = input("Book to search: ")
            ok, msg = system.search_book(name)
            print(msg)
        
        elif choice == "7":
            print(system.display_category_tree())
        
        elif choice == "8":
            print("Goodbye!")
            break
        
        else:
            print("Invalid choice")
        
        if choice != "8":
            input("Press Enter...")

if __name__ == "__main__":
    main()
        